const MAILGUN_CONFIG ={
    'baseURL' : 'https://api.mailgun.net/v3/',
    'domain' : 'mail.nbitcs.com',
    'apiKey' : '932419afbb4fe174b1c69995a062c76d-f7910792-3c1da098',
    'fromAddress' : "SiteMinder <SiteMinder@mail.nbitcs.com>"
};

module.exports = MAILGUN_CONFIG;