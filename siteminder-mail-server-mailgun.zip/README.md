# siteminder-mail-server
SiteMinder Technical Test Mail Server BE
